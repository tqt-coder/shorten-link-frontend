function Footer(){
    return (
        <footer>
            <p>&copy; {new Date().getFullYear()} Kien truc su giai phap!</p>
        </footer>
    )
}
export default Footer