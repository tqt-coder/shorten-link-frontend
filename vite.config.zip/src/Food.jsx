function Food(){
    const food1 = "Pizza";
    const food2 = "Burger";
    const food3 = "Ramen";
    return(
        <ul>
            <li>{food1}</li>
            <li>{food2}</li>
            <li>{food3}</li>
        </ul>

    );
}
export default Food